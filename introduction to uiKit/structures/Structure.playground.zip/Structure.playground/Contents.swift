//import UIKit
//
//var greeting = "Hello, playground"
//struct Person{
//    var name : String
//    var age : Int
//    func printPerson(){
//        print("Hey,  my name is \(self.name) and I am \(self.age) years old")
//    }
//}
//    
//let Udi = Person(name: "Udita" , age: 19)
////print(person.name)
////print(person.age)
//print(Udi)
//Udi.printPerson()
//print(MemoryLayout<Person>.size)

//struct Shirt{
//    var size: String
//    var color: String
//    
//    mutating func setSize(newSize: String){
//        self.size = newSize
//    }
//    
//    
//    
//}
//var myShirt = Shirt(size: "M", color: "Blue")
//print("before change \(myShirt)")
//
//myShirt.color = "Red"
//print("after change \(myShirt)")



//let yourShirt = Shirt(size: "L" , color: "Black")
//yourShirt.size = "S"
//print(myShirt)
//print(yourShirt)
//myShirt = Shirt(size: "S" , color: "Red")
//print(myShirt)


//struct Car{
//    var type: String
//    var color: String
//    var year : Int
//    
//    func startEngine(){
//        print(" the \(type) \(color) \(year) car's engine is starting")
//    }
//    
//    func drive(){
//        print("the \(type) \(color) \(year) car is driving ")
//    }
//    func park(){
//        print( "the \(type) \(color) \(year) car is parked ")
//    }
//    func steer(direction: String){
//        print("the \(type) \(color) \(year) car is steering \(direction)")
//    }
//    
//    }
//
//let firstCar =  Car(type: "Toyota" , color: "Red" , year: 2020)
//firstCar.startEngine()
//firstCar.drive()
//firstCar.park()
//firstCar.steer(direction: "left")




struct Temperature{
    var cel : Double = 0.0 // default value to the property of cel
    
    
    init(){
        self.cel = 0.0
    }
    init(cel: Double){
        self.cel = cel
    }
    init(fer: Double){
        self.cel = (fer - 32) / 1.8
    }
}


var chitkaraUniversityt = Temperature(cel: 24)  //member intializer
print(chitkaraUniversityt)
 var iosLab = Temperature()
print(iosLab)
var newton = Temperature(fer: 45)
print(newton)
